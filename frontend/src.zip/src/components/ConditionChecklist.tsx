"use client";

import React from "react";
import { HourlyForecastItem, LocationMetadata } from "@/types/stargazing";
import { TONE } from "@/lib/theme";

const DISPLAY = "font-[family-name:var(--font-display)]";
const MUTED = "#9097ad";

interface ConditionChecklistProps {
  currentHour: HourlyForecastItem;
  location: LocationMetadata;
}

interface ReadingProps {
  label: string;
  status: string;
  tone: string;
  value: React.ReactNode;
  unit: string;
  detail: React.ReactNode;
}

const Reading: React.FC<ReadingProps> = ({ label, status, tone, value, unit, detail }) => (
  <div className="flex flex-col gap-2 border-t border-[#232b47] py-4">
    <div className="flex items-baseline justify-between gap-3">
      <dt className="text-sm text-[#9097ad]">{label}</dt>
      <dd className="flex items-center gap-1.5 text-xs" style={{ color: tone }}>
        <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: tone }} aria-hidden />
        {status}
      </dd>
    </div>

    <dd className="flex items-baseline gap-1.5">
      <span className={`${DISPLAY} text-4xl leading-none tabular-nums text-[#e9e6dc]`}>{value}</span>
      <span className="text-sm text-[#9097ad]">{unit}</span>
    </dd>

    <dd className="flex flex-wrap gap-x-4 gap-y-0.5 text-xs text-[#9097ad]">{detail}</dd>
  </div>
);

const Fact: React.FC<{ label: string; value: React.ReactNode; color?: string }> = ({
  label,
  value,
  color,
}) => (
  <span>
    {label}{" "}
    <span className="tabular-nums" style={{ color: color ?? "#d4d1c6" }}>
      {value}
    </span>
  </span>
);

export const ConditionChecklist: React.FC<ConditionChecklistProps> = ({
  currentHour,
  location,
}) => {
  // 1. Cloud cover
  const totalClouds = currentHour.cloud_cover;
  const isCloudOptimal = totalClouds <= 15;
  const isCloudModerate = totalClouds <= 40;

  // 2. Milky Way core
  const mwAlt = currentHour.milky_way_core_altitude;
  const isMwAbove = mwAlt > 0;
  const isMwPrime = currentHour.is_milky_way_prime_window;

  // 3. Moon
  const isMoonDown = currentHour.moon_altitude <= 0;
  const moonIllumPct = Math.round(currentHour.moon_illumination * 100);

  // 4. Dew spread
  const dewSpread = currentHour.dew_point_spread ?? 5.0;
  const isDewSafe = dewSpread >= 3.0;

  // 5. Bortle
  const bortle = location.bortle_scale;

  // 6. Visibility
  const visKm = currentHour.visibility_meters
    ? Math.round(currentHour.visibility_meters / 1000)
    : 25;

  const degrees = (n: number | null | undefined) => (n != null ? `${n}°C` : "—");
  const signed = (n: number) => `${Math.round(n)}`.replace("-", "−");

  const readings: ReadingProps[] = [
    {
      label: "Cloud cover",
      status: isCloudOptimal ? "Clear" : isCloudModerate ? "Partly cloudy" : "Overcast",
      tone: isCloudOptimal ? TONE.excellent : isCloudModerate ? TONE.fair : TONE.poor,
      value: Math.round(totalClouds),
      unit: "%",
      detail: (
        <>
          <Fact label="High" value={`${Math.round(currentHour.cloud_cover_high)}%`} />
          <Fact label="Mid" value={`${Math.round(currentHour.cloud_cover_mid)}%`} />
          <Fact label="Low" value={`${Math.round(currentHour.cloud_cover_low)}%`} />
        </>
      ),
    },
    {
      label: "Milky Way core",
      status: isMwPrime ? "Prime window" : isMwAbove ? "Above the horizon" : "Below the horizon",
      tone: isMwPrime ? TONE.violet : isMwAbove ? "#d4d1c6" : MUTED,
      value: isMwAbove ? `+${Math.round(mwAlt)}` : signed(mwAlt),
      unit: "° altitude",
      detail: <Fact label="Azimuth" value={`${Math.round(currentHour.milky_way_core_azimuth)}°`} />,
    },
    {
      label: "Moon",
      status: isMoonDown ? "Moon down" : moonIllumPct < 30 ? "Faint" : "Bright",
      tone: isMoonDown ? TONE.excellent : moonIllumPct < 30 ? TONE.good : TONE.fair,
      value: moonIllumPct,
      unit: "% lit",
      detail: (
        <>
          <span className="text-[#d4d1c6]">{currentHour.moon_phase_name}</span>
          <Fact label="Altitude" value={`${Math.round(currentHour.moon_altitude)}°`} />
          <Fact
            label="Glare"
            value={isMoonDown ? "None" : "Active"}
            color={isMoonDown ? TONE.excellent : TONE.fair}
          />
        </>
      ),
    },
    {
      label: "Dew margin",
      status: isDewSafe ? "Dry" : "Dew risk",
      tone: isDewSafe ? TONE.excellent : TONE.poor,
      value: dewSpread.toFixed(1),
      unit: "°C between air and dew point",
      detail: (
        <>
          <Fact label="Air" value={degrees(currentHour.temperature)} />
          <Fact label="Dew point" value={degrees(currentHour.dew_point)} />
        </>
      ),
    },
    {
      label: "Light pollution",
      status: bortle <= 2 ? "Dark sky" : bortle <= 4 ? "Rural" : bortle <= 6 ? "Suburban" : "Urban",
      tone: bortle <= 3 ? TONE.excellent : bortle <= 5 ? TONE.fair : TONE.poor,
      value: bortle,
      unit: "Bortle class, 1 to 9",
      detail: (
        <>
          <Fact label="Elevation" value={`${location.elevation} m`} />
          <Fact label="Source" value={location.bortle_source} />
        </>
      ),
    },
    {
      label: "Transparency",
      status: visKm >= 30 ? "Excellent" : "Moderate",
      tone: visKm >= 30 ? TONE.good : TONE.fair,
      value: visKm,
      unit: "km visibility",
      detail: (
        <>
          <Fact label="Humidity" value={`${Math.round(currentHour.relative_humidity)}%`} />
          <span style={{ color: currentHour.is_astronomical_night ? TONE.excellent : TONE.fair }}>
            {currentHour.is_astronomical_night ? "Astronomical night" : "Twilight"}
          </span>
        </>
      ),
    },
  ];

  return (
    <section className="w-full">
      <h2 className={`${DISPLAY} mb-4 text-xl`}>
        Conditions at {currentHour.timestamp_utc.slice(11, 16)} UTC
      </h2>

      <dl className="grid grid-cols-1 gap-x-10 border-b border-[#232b47] sm:grid-cols-2">
        {readings.map((r) => (
          <Reading key={r.label} {...r} />
        ))}
      </dl>
    </section>
  );
};
