"use client";

import React, { useState } from "react";
import {
  Calendar,
  SlidersHorizontal,
  LocateFixed,
  Search,
} from "lucide-react";

export interface LocationPreset {
  name: string;
  lat: number;
  lon: number;
  elevation: number;
  bortle: number;
  country: string;
}

export const PRESET_LOCATIONS: LocationPreset[] = [
  {
    name: "Mount Bromo",
    lat: -7.9425,
    lon: 112.953,
    elevation: 2329,
    bortle: 3,
    country: "Indonesia",
  },
  {
    name: "Mauna Kea",
    lat: 19.8206,
    lon: -155.4681,
    elevation: 4205,
    bortle: 1,
    country: "Hawaii",
  },
  {
    name: "Atacama",
    lat: -24.6272,
    lon: -70.4042,
    elevation: 2635,
    bortle: 1,
    country: "Chile",
  },
  {
    name: "Joshua Tree",
    lat: 33.8734,
    lon: -115.901,
    elevation: 820,
    bortle: 3,
    country: "USA",
  },
  {
    name: "Jakarta",
    lat: -6.1751,
    lon: 106.865,
    elevation: 10,
    bortle: 9,
    country: "Indonesia",
  },
];

interface LocationSearchProps {
  currentLat: number;
  currentLon: number;
  currentDate?: string;
  onSearch: (lat: number, lon: number, date?: string, elevation?: number, bortle?: number) => void;
  isLoading: boolean;
}

const FOCUS = "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#9db8ff]";

export const LocationSearch: React.FC<LocationSearchProps> = ({
  currentLat,
  currentLon,
  currentDate,
  onSearch,
  isLoading,
}) => {
  const [latInput, setLatInput] = useState(currentLat.toString());
  const [lonInput, setLonInput] = useState(currentLon.toString());
  const [elevInput, setElevInput] = useState("");
  const [dateInput, setDateInput] = useState(currentDate || new Date().toISOString().slice(0, 10));
  const [showCustom, setShowCustom] = useState(false);
  const [isLocating, setIsLocating] = useState(false);

  const handleSelectPreset = (preset: LocationPreset) => {
    setLatInput(preset.lat.toString());
    setLonInput(preset.lon.toString());
    setElevInput(preset.elevation.toString());
    onSearch(preset.lat, preset.lon, dateInput, preset.elevation, preset.bortle);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const lat = parseFloat(latInput);
    const lon = parseFloat(lonInput);
    const elev = elevInput ? parseFloat(elevInput) : undefined;
    if (!isNaN(lat) && !isNaN(lon)) {
      onSearch(lat, lon, dateInput, elev);
    }
  };

  const handleDetectLocation = () => {
    if (!navigator.geolocation) {
      alert("Geolocation is not supported by your browser.");
      return;
    }
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const uLat = Number(pos.coords.latitude.toFixed(4));
        const uLon = Number(pos.coords.longitude.toFixed(4));
        const uElev = pos.coords.altitude ? Math.round(pos.coords.altitude) : undefined;
        setLatInput(uLat.toString());
        setLonInput(uLon.toString());
        if (uElev !== undefined) setElevInput(uElev.toString());
        onSearch(uLat, uLon, dateInput, uElev);
        setIsLocating(false);
      },
      (err) => {
        console.warn("Geolocation failed:", err.message);
        setIsLocating(false);
      },
      { timeout: 8000 }
    );
  };

  return (
    <div className="flex w-full flex-col gap-3">
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Site selector */}
        <div
          role="group"
          aria-label="Observing site"
          className="flex max-w-full items-center gap-0.5 overflow-x-auto rounded-md border border-[#232b47] bg-[#11172b] p-0.5"
        >
          {PRESET_LOCATIONS.map((preset) => {
            const isSelected =
              Math.abs(currentLat - preset.lat) < 0.01 && Math.abs(currentLon - preset.lon) < 0.01;
            return (
              <button
                key={preset.name}
                type="button"
                onClick={() => handleSelectPreset(preset)}
                disabled={isLoading}
                aria-pressed={isSelected}
                title={`${preset.name}, ${preset.country}. Bortle class ${preset.bortle}`}
                className={`whitespace-nowrap rounded-[5px] px-3 py-1.5 text-sm transition-colors motion-reduce:transition-none disabled:opacity-50 ${FOCUS} ${
                  isSelected
                    ? "bg-[#232b47] text-[#e9e6dc]"
                    : "text-[#9097ad] hover:text-[#e9e6dc]"
                }`}
              >
                {preset.name}
                <span className="ml-1.5 hidden text-xs text-[#9097ad] md:inline">
                  Bortle {preset.bortle}
                </span>
              </button>
            );
          })}
        </div>

        {/* Date, GPS, coordinates */}
        <div className="flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-2 rounded-md border border-[#232b47] bg-[#11172b] px-2.5 py-1.5 text-sm text-[#9097ad] focus-within:ring-2 focus-within:ring-[#9db8ff]">
            <Calendar className="h-3.5 w-3.5 shrink-0" aria-hidden />
            <span className="sr-only">Forecast date</span>
            <input
              type="date"
              value={dateInput}
              onChange={(e) => {
                setDateInput(e.target.value);
                const lat = parseFloat(latInput);
                const lon = parseFloat(lonInput);
                const elev = elevInput ? parseFloat(elevInput) : undefined;
                if (!isNaN(lat) && !isNaN(lon)) {
                  onSearch(lat, lon, e.target.value, elev);
                }
              }}
              className="bg-transparent text-sm text-[#e9e6dc] tabular-nums [color-scheme:dark] focus:outline-none"
            />
          </label>

          <button
            type="button"
            onClick={handleDetectLocation}
            disabled={isLocating || isLoading}
            title="Use my current location"
            className={`flex items-center gap-1.5 rounded-md border border-[#232b47] bg-[#11172b] px-2.5 py-1.5 text-sm text-[#9097ad] transition-colors hover:text-[#e9e6dc] motion-reduce:transition-none disabled:opacity-50 ${FOCUS}`}
          >
            <LocateFixed className={`h-3.5 w-3.5 ${isLocating ? "animate-spin" : ""}`} aria-hidden />
            <span className="hidden md:inline">{isLocating ? "Locating…" : "Use my location"}</span>
            <span className="sr-only md:hidden">Use my location</span>
          </button>

          <button
            type="button"
            onClick={() => setShowCustom(!showCustom)}
            aria-expanded={showCustom}
            className={`flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-sm transition-colors motion-reduce:transition-none ${FOCUS} ${
              showCustom
                ? "border-[#3a4466] bg-[#232b47] text-[#e9e6dc]"
                : "border-[#232b47] bg-[#11172b] text-[#9097ad] hover:text-[#e9e6dc]"
            }`}
          >
            <SlidersHorizontal className="h-3.5 w-3.5" aria-hidden />
            Coordinates
          </button>
        </div>
      </div>

      {showCustom && (
        <form
          onSubmit={handleCustomSubmit}
          className="grid grid-cols-1 gap-3 rounded-md border border-[#232b47] bg-[#11172b] p-4 sm:grid-cols-[1fr_1fr_1fr_auto] sm:items-end"
        >
          {[
            { label: "Latitude", placeholder: "-7.9425", value: latInput, setter: setLatInput },
            { label: "Longitude", placeholder: "112.9530", value: lonInput, setter: setLonInput },
            { label: "Elevation (m)", placeholder: "Optional", value: elevInput, setter: setElevInput },
          ].map(({ label, placeholder, value, setter }) => (
            <label key={label} className="flex flex-col gap-1.5 text-xs text-[#9097ad]">
              {label}
              <input
                type="number"
                step="any"
                placeholder={placeholder}
                value={value}
                onChange={(e) => setter(e.target.value)}
                className={`w-full rounded-md border border-[#232b47] bg-[#0b0f1e] px-2.5 py-1.5 text-sm text-[#e9e6dc] tabular-nums placeholder:text-[#4a5272] ${FOCUS}`}
              />
            </label>
          ))}

          <button
            type="submit"
            disabled={isLoading}
            className={`flex items-center justify-center gap-1.5 rounded-md bg-[#e9e6dc] px-4 py-1.5 text-sm font-medium text-[#0b0f1e] transition-opacity hover:opacity-90 motion-reduce:transition-none disabled:opacity-40 ${FOCUS}`}
          >
            <Search className="h-3.5 w-3.5" aria-hidden />
            Get forecast
          </button>
        </form>
      )}
    </div>
  );
};
