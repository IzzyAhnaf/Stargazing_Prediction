"use client";

import React from "react";
import { HourlyForecastItem, LocationMetadata } from "@/types/stargazing";
import { TONE } from "@/lib/theme";

const DISPLAY = "font-[family-name:var(--font-display)]";

interface CameraSettingsCardProps {
  currentHour: HourlyForecastItem;
  location: LocationMetadata;
}

interface SettingRow {
  label: string;
  value: string;
  note: string;
  color?: string;
}

export const CameraSettingsCard: React.FC<CameraSettingsCardProps> = ({
  currentHour,
  location,
}) => {
  const bortle = location.bortle_scale;
  const dewSpread = currentHour.dew_point_spread ?? 5.0;
  const moonIllum = currentHour.moon_illumination;
  const isMoonDown = currentHour.moon_altitude <= 0;

  let recIso = "3200–6400";
  let isoNote = "Low light pollution, so high sensitivity works without blowing out highlights.";
  if (bortle >= 7 || (!isMoonDown && moonIllum > 0.5)) {
    recIso = "400–800";
    isoNote = "Bright skyglow or moonlight. A lower ISO keeps the sensor from saturating.";
  } else if (bortle >= 4) {
    recIso = "1600–3200";
    isoNote = "A balance between noise and suburban skyglow.";
  }

  const dewWarning = dewSpread < 3.0;

  const rows: SettingRow[] = [
    { label: "ISO", value: recIso, note: isoNote },
    {
      label: "Shutter (NPF rule)",
      value: "15–20 s",
      note: "Keeps stars pinpoint on a 24 mm full-frame lens, without trails from Earth's rotation.",
    },
    {
      label: "Aperture",
      value: "f/1.4–f/2.8",
      note: "Open as wide as the lens allows to resolve faint dust lanes in the Milky Way.",
    },
    {
      label: "Dew heater band",
      value: dewWarning ? "Required" : "Not needed",
      color: dewWarning ? TONE.poor : TONE.excellent,
      note: dewWarning
        ? `Only ${dewSpread.toFixed(1)}°C between air and dew point, so the front lens is likely to fog.`
        : `${dewSpread.toFixed(1)}°C between air and dew point, so the optics should stay dry.`,
    },
  ];

  return (
    <section className="w-full">
      <h2 className={`${DISPLAY} text-xl`}>Camera settings</h2>
      <p className="mb-4 mt-1 text-sm text-[#9097ad]">
        Starting points for Bortle class {bortle} and the moon at this hour.
      </p>

      <dl className="border-b border-[#232b47]">
        {rows.map((row) => (
          <div
            key={row.label}
            className="grid grid-cols-[1fr_auto] items-baseline gap-x-6 gap-y-1 border-t border-[#232b47] py-4"
          >
            <dt className="text-sm text-[#9097ad]">{row.label}</dt>
            <dd
              className={`${DISPLAY} text-right text-2xl leading-none tabular-nums`}
              style={{ color: row.color ?? "#e9e6dc" }}
            >
              {row.value}
            </dd>
            <dd className="col-span-2 max-w-[46ch] text-xs leading-relaxed text-[#9097ad]">
              {row.note}
            </dd>
          </div>
        ))}
      </dl>
    </section>
  );
};
