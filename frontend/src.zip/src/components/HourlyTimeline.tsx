"use client";

import React from "react";
import { HourlyForecastItem } from "@/types/stargazing";
import { scoreTone, TONE } from "@/lib/theme";

const DISPLAY = "font-[family-name:var(--font-display)]";

interface HourlyTimelineProps {
  hourlyData: HourlyForecastItem[];
  selectedHourIndex: number;
  onSelectHour: (index: number) => void;
}

const LEGEND = [
  { color: TONE.excellent, label: "Excellent", range: "80 and up" },
  { color: TONE.good, label: "Good", range: "65 to 79" },
  { color: TONE.fair, label: "Fair", range: "45 to 64" },
  { color: TONE.poor, label: "Poor", range: "under 45" },
];

const THRESHOLDS = [45, 65, 80];

export const HourlyTimeline: React.FC<HourlyTimelineProps> = ({
  hourlyData,
  selectedHourIndex,
  onSelectHour,
}) => {
  // Night hours only (sun below the horizon)
  const nightHours = hourlyData.filter((item) => item.sun_altitude < 0);
  const displayItems = nightHours.length > 0 ? nightHours.slice(0, 18) : hourlyData.slice(0, 16);

  return (
    <section className="w-full rounded-md border border-[#232b47] bg-[#11172b] p-5 sm:p-6 flex flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-x-8 gap-y-3">
        <div>
          <h2 className={`${DISPLAY} text-xl`}>Clarity through the night</h2>
          <p className="mt-1 text-sm text-[#9097ad]">
            Dusk to dawn, in UTC. Select an hour to see its conditions.
          </p>
        </div>

        <ul className="flex flex-wrap gap-x-5 gap-y-1.5 text-xs text-[#9097ad]">
          {LEGEND.map((l) => (
            <li key={l.label} className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: l.color }} aria-hidden />
              <span>
                <span className="text-[#e9e6dc]">{l.label}</span> {l.range}
              </span>
            </li>
          ))}
        </ul>
      </div>

      <div className="overflow-x-auto pb-1">
        <div className="relative w-full pt-6" style={{ minWidth: displayItems.length * 40 }}>
          {/* Threshold guides, aligned to the bar area below */}
          <div className="pointer-events-none absolute inset-x-0 top-6 h-40" aria-hidden>
            {THRESHOLDS.map((t) => (
              <div
                key={t}
                className="absolute inset-x-0 border-t border-dashed border-[#2a3351]"
                style={{ bottom: `${t}%` }}
              />
            ))}
          </div>

          <div className="relative flex gap-1">
            {displayItems.map((item) => {
              const originalIndex = hourlyData.indexOf(item);
              const isSelected = originalIndex === selectedHourIndex;
              const score = item.stargazing_score;
              const timeStr = item.timestamp_utc.slice(11, 16);
              const mwAlt = Math.round(item.milky_way_core_altitude);
              const height = Math.max(3, Math.min(100, score));
              const color = scoreTone(score).color;

              return (
                <button
                  key={item.timestamp_utc}
                  type="button"
                  onClick={() => onSelectHour(originalIndex)}
                  aria-pressed={isSelected}
                  aria-label={`${timeStr} UTC, clarity ${Math.round(score)}, cloud cover ${Math.round(item.cloud_cover)} percent`}
                  title={`${timeStr} UTC: clarity ${Math.round(score)}, cloud ${Math.round(item.cloud_cover)}%`}
                  className={`relative flex min-w-[36px] flex-1 flex-col items-center gap-2 rounded-sm pb-2 transition-colors motion-reduce:transition-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#9db8ff] ${
                    isSelected ? "bg-white/[0.06]" : "hover:bg-white/[0.03]"
                  }`}
                >
                  <span className="relative flex h-40 w-full items-end justify-center">
                    {isSelected && (
                      <span
                        className="absolute left-1/2 -translate-x-1/2 text-xs font-medium tabular-nums"
                        style={{ bottom: `calc(${height}% + 4px)`, color }}
                      >
                        {Math.round(score)}
                      </span>
                    )}
                    <span
                      className="block w-3.5 rounded-t-[3px] transition-opacity motion-reduce:transition-none"
                      style={{
                        height: `${height}%`,
                        backgroundColor: color,
                        opacity: isSelected ? 1 : 0.5,
                      }}
                    />
                  </span>

                  <span
                    className={`text-xs tabular-nums ${isSelected ? "text-[#e9e6dc] font-medium" : "text-[#b3b0a6]"}`}
                  >
                    {timeStr}
                  </span>
                  <span
                    className="text-[11px] tabular-nums"
                    style={{ color: mwAlt > 0 ? TONE.violet : "#4a5272" }}
                  >
                    {mwAlt > 0 ? `${mwAlt}°` : "–"}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <p className="text-xs leading-relaxed text-[#9097ad]">
        Dashed lines mark scores of 45, 65 and 80. The violet figure under each hour is how high the Milky Way core stands above the horizon.
      </p>
    </section>
  );
};
