"use client";

import React, { useState, useEffect, useCallback, useSyncExternalStore } from "react";
import { Telescope, RefreshCw, Clock } from "lucide-react";
import { fetchStargazingForecast } from "@/lib/api";
import { StargazingResponse } from "@/types/stargazing";
import { ScoreGauge } from "@/components/ScoreGauge";
import { HourlyTimeline } from "@/components/HourlyTimeline";
import { ConditionChecklist } from "@/components/ConditionChecklist";
import { SHAPDrawer } from "@/components/SHAPDrawer";
import { LocationSearch, PRESET_LOCATIONS } from "@/components/LocationSearch";
import { CameraSettingsCard } from "@/components/CameraSettingsCard";
import { SkyScene, sceneForSite } from "@/components/SkyScene";

const DISPLAY = "font-[family-name:var(--font-display)]";

const emptySubscribe = () => () => {};

function formatDate(iso: string) {
  try {
    return new Date(`${iso}T00:00:00Z`).toLocaleDateString("en-GB", {
      day: "numeric",
      month: "long",
      year: "numeric",
      timeZone: "UTC",
    });
  } catch {
    return iso;
  }
}

export default function StargazingDashboard() {
  const isMounted = useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );

  // Default to Mount Bromo, Indonesia
  const [latitude, setLatitude] = useState(-7.9425);
  const [longitude, setLongitude] = useState(112.953);
  const [elevation, setElevation] = useState<number | undefined>(2329);
  const [bortle, setBortle] = useState<number | undefined>(3);
  const [date, setDate] = useState("2026-11-06");
  const [data, setData] = useState<StargazingResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedHourIndex, setSelectedHourIndex] = useState(0);
  const [currentTimeStr, setCurrentTimeStr] = useState<string>("");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTimeStr(
        now.toISOString().slice(0, 10) + " " + now.toISOString().slice(11, 16) + " UTC"
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadForecast = useCallback(
    async (lat: number, lon: number, targetDate?: string, elev?: number, bortleVal?: number) => {
      setLoading(true);
      try {
        const resp = await fetchStargazingForecast(lat, lon, targetDate, elev, bortleVal);
        setData(resp);
        if (resp.hourly_forecast && resp.hourly_forecast.length > 0) {
          const peakIdx = resp.hourly_forecast.findIndex(
            (h) => h.timestamp_utc === resp.summary.best_window.peak_time
          );
          const firstNightIdx = resp.hourly_forecast.findIndex((h) => h.sun_altitude < 0);
          setSelectedHourIndex(peakIdx !== -1 ? peakIdx : firstNightIdx !== -1 ? firstNightIdx : 0);
        }
      } catch (err) {
        console.error("Failed to load forecast:", err);
      } finally {
        setLoading(false);
      }
    },
    []
  );

  useEffect(() => {
    let ignore = false;
    const fetchInitial = async () => {
      try {
        const resp = await fetchStargazingForecast(latitude, longitude, date, elevation, bortle);
        if (!ignore) {
          setData(resp);
          if (resp.hourly_forecast && resp.hourly_forecast.length > 0) {
            const peakIdx = resp.hourly_forecast.findIndex(
              (h) => h.timestamp_utc === resp.summary.best_window.peak_time
            );
            const firstNightIdx = resp.hourly_forecast.findIndex((h) => h.sun_altitude < 0);
            setSelectedHourIndex(peakIdx !== -1 ? peakIdx : firstNightIdx !== -1 ? firstNightIdx : 0);
          }
        }
      } catch (err) {
        if (!ignore) console.error("Failed to load initial forecast:", err);
      } finally {
        if (!ignore) {
          setLoading(false);
        }
      }
    };

    fetchInitial();

    return () => {
      ignore = true;
    };
  }, [latitude, longitude, date, elevation, bortle]);

  const handleSearch = (newLat: number, newLon: number, newDate?: string, newElev?: number, newBortle?: number) => {
    setLatitude(newLat);
    setLongitude(newLon);
    if (newDate) setDate(newDate);
    setElevation(newElev);
    setBortle(newBortle);
    loadForecast(newLat, newLon, newDate, newElev, newBortle);
  };

  const selectedHour =
    data && data.hourly_forecast && data.hourly_forecast[selectedHourIndex]
      ? data.hourly_forecast[selectedHourIndex]
      : data?.hourly_forecast?.[0];

  const site = PRESET_LOCATIONS.find(
    (p) => Math.abs(p.lat - latitude) < 0.01 && Math.abs(p.lon - longitude) < 0.01
  );

  if (!isMounted) {
    return (
      <main className="flex min-h-screen flex-col items-center justify-center bg-[#0b0f1e] p-4 text-[#e9e6dc]" suppressHydrationWarning>
        <div className="flex flex-col items-center gap-3 text-sm text-[#9097ad]" suppressHydrationWarning>
          <div className="h-5 w-5 animate-spin rounded-full border border-[#3a4466] border-t-[#e9e6dc] motion-reduce:animate-none" />
          <p>Loading forecast…</p>
        </div>
      </main>
    );
  }

  return (
    <main
      className="flex min-h-screen flex-col items-center bg-[#0b0f1e] px-4 pb-12 pt-5 text-[#e9e6dc] sm:px-6 lg:px-10"
      suppressHydrationWarning
    >
      <div className="flex w-full max-w-6xl flex-col gap-10">
        {/* Header */}
        <header
          className="flex items-center justify-between gap-4 border-b border-[#232b47] pb-4"
          suppressHydrationWarning
        >
          <div className="flex min-w-0 items-center gap-2.5">
            <Telescope className="h-4 w-4 shrink-0 text-[#9097ad]" aria-hidden />
            <span className="truncate text-sm font-medium">Stargazing &amp; Milky Way forecast</span>
          </div>

          <div className="flex shrink-0 items-center gap-3 text-sm">
            {currentTimeStr && (
              <span className="hidden items-center gap-1.5 tabular-nums text-[#9097ad] md:flex">
                <Clock className="h-3.5 w-3.5" aria-hidden />
                {currentTimeStr}
              </span>
            )}

            <button
              type="button"
              onClick={() => loadForecast(latitude, longitude, date, elevation, bortle)}
              disabled={loading}
              className="flex items-center gap-1.5 rounded-md border border-[#232b47] bg-[#11172b] px-2.5 py-1.5 text-[#9097ad] transition-colors hover:text-[#e9e6dc] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#9db8ff] motion-reduce:transition-none disabled:opacity-50"
              title="Refresh forecast"
            >
              <RefreshCw
                className={`h-3.5 w-3.5 ${loading ? "animate-spin motion-reduce:animate-none" : ""}`}
                aria-hidden
              />
              <span className="hidden sm:inline">{loading ? "Fetching…" : "Refresh"}</span>
            </button>
          </div>
        </header>

        {/* Hero: scenery for the selected site, driven by the selected hour */}
        <section className="relative h-[300px] overflow-hidden rounded-md border border-[#232b47] sm:h-[400px]">
          <SkyScene
            className="absolute inset-0"
            scene={sceneForSite(site?.name)}
            bortle={data?.location.bortle_scale ?? site?.bortle ?? bortle ?? 3}
            sunAltitude={selectedHour ? selectedHour.sun_altitude : -30}
            cloudCover={selectedHour ? selectedHour.cloud_cover : 0}
            moonIllumination={selectedHour ? selectedHour.moon_illumination : 0}
            moonAltitude={selectedHour ? selectedHour.moon_altitude : -10}
            milkyWayAltitude={selectedHour ? selectedHour.milky_way_core_altitude : 25}
          />

          {selectedHour && (
            <p className="absolute left-4 top-4 rounded-md bg-[#0b0f1e]/70 px-2.5 py-1 text-xs tabular-nums text-[#d4d1c6]">
              Sky at {selectedHour.timestamp_utc.slice(11, 16)} UTC
            </p>
          )}

          <div className="absolute inset-x-0 bottom-0 flex flex-col gap-3 bg-gradient-to-t from-[#0b0f1e]/95 via-[#0b0f1e]/60 to-transparent px-5 pb-5 pt-20 sm:px-8 sm:pb-7">
            <p className="text-sm text-[#b3b0a6]">Forecast for {formatDate(date)}</p>
            <h1 className={`${DISPLAY} text-4xl tracking-tight sm:text-5xl`}>
              {site ? site.name : "Custom location"}
            </h1>
            {data && (
              <dl className="flex flex-wrap gap-x-6 gap-y-1 text-sm text-[#b3b0a6]">
                <div className="flex gap-1.5">
                  <dt>Latitude</dt>
                  <dd className="tabular-nums text-[#e9e6dc]">{data.location.latitude}</dd>
                </div>
                <div className="flex gap-1.5">
                  <dt>Longitude</dt>
                  <dd className="tabular-nums text-[#e9e6dc]">{data.location.longitude}</dd>
                </div>
                <div className="flex gap-1.5">
                  <dt>Elevation</dt>
                  <dd className="tabular-nums text-[#e9e6dc]">{data.location.elevation} m</dd>
                </div>
                <div className="flex gap-1.5">
                  <dt>Bortle class</dt>
                  <dd className="tabular-nums text-[#e9e6dc]">
                    {data.location.bortle_scale}
                    <span className="text-[#b3b0a6]"> ({data.location.bortle_source})</span>
                  </dd>
                </div>
              </dl>
            )}
          </div>
        </section>

        <LocationSearch
          currentLat={latitude}
          currentLon={longitude}
          currentDate={date}
          onSearch={handleSearch}
          isLoading={loading}
        />

        {data && selectedHour && (
          <div
            aria-busy={loading}
            className={`flex flex-col gap-10 transition-opacity motion-reduce:transition-none ${
              loading ? "opacity-60" : "opacity-100"
            }`}
          >
            <div className="grid grid-cols-1 items-start gap-10 lg:grid-cols-12">
              <div className="lg:col-span-5">
                <ScoreGauge
                  score={selectedHour.stargazing_score}
                  ratingCategory={selectedHour.rating_category}
                  bestWindow={data.summary.best_window}
                />
              </div>
              <div className="lg:col-span-7">
                <ConditionChecklist currentHour={selectedHour} location={data.location} />
              </div>
            </div>

            <HourlyTimeline
              hourlyData={data.hourly_forecast}
              selectedHourIndex={selectedHourIndex}
              onSelectHour={setSelectedHourIndex}
            />

            <div className="grid grid-cols-1 items-start gap-10 lg:grid-cols-12">
              <div className="lg:col-span-7">
                <SHAPDrawer
                  explanation={selectedHour.explanation}
                  score={selectedHour.stargazing_score}
                  timeStr={selectedHour.timestamp_utc.slice(11, 16)}
                />
              </div>
              <div className="lg:col-span-5">
                <CameraSettingsCard currentHour={selectedHour} location={data.location} />
              </div>
            </div>
          </div>
        )}

        {loading && !data && (
          <div className="flex w-full flex-col items-center justify-center gap-3 py-20 text-sm text-[#9097ad]">
            <div className="h-5 w-5 animate-spin rounded-full border border-[#3a4466] border-t-[#e9e6dc] motion-reduce:animate-none" />
            <p>Fetching the forecast…</p>
          </div>
        )}

        {!loading && !data && (
          <div className="w-full rounded-md border border-[#232b47] bg-[#11172b] p-6">
            <h2 className={`${DISPLAY} text-xl`}>The forecast could not be loaded</h2>
            <p className="mt-2 max-w-[60ch] text-sm leading-relaxed text-[#9097ad]">
              Check that the forecast API is running, then select Refresh to try again.
            </p>
          </div>
        )}

        <footer className="mt-6 max-w-2xl border-t border-[#232b47] pt-5 text-xs leading-relaxed text-[#9097ad]">
          Clarity scores come from an XGBoost 3.4.1 model explained with TreeSHAP. Weather data is
          from Open-Meteo, sun, moon and Milky Way positions are computed with PyEphem, and the API
          runs on FastAPI.
        </footer>
      </div>
    </main>
  );
}
